/*
Navicat MySQL Data Transfer

Source Server         : No
Source Server Version : 80019
Source Host           : localhost:3306
Source Database       : manage

Target Server Type    : MYSQL
Target Server Version : 80019
File Encoding         : 65001

Date: 2020-07-15 10:58:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `stu_id` varchar(4) NOT NULL,
  `stu_name` varchar(15) NOT NULL,
  `python` int NOT NULL,
  `c` int NOT NULL,
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1001', '黄海涛', '88', '99');
INSERT INTO `student` VALUES ('1002', '聂风', '67', '88');
INSERT INTO `student` VALUES ('1003', '沈复', '65', '77');
INSERT INTO `student` VALUES ('1004', '李逵', '65', '99');
INSERT INTO `student` VALUES ('1005', '紫嫣', '34', '76');
INSERT INTO `student` VALUES ('1006', '憨憨', '87', '67');
INSERT INTO `student` VALUES ('1007', '雨', '88', '56');
INSERT INTO `student` VALUES ('1008', '余罪', '44', '99');
INSERT INTO `student` VALUES ('1009', '莫离', '89', '67');
INSERT INTO `student` VALUES ('1010', '晓', '86', '90');
INSERT INTO `student` VALUES ('1011', '姬雪', '78', '43');
INSERT INTO `student` VALUES ('1012', '黎明', '45', '56');
INSERT INTO `student` VALUES ('1013', '逆风', '89', '56');
INSERT INTO `student` VALUES ('1014', '志远', '45', '99');
INSERT INTO `student` VALUES ('1015', '行者', '65', '23');
INSERT INTO `student` VALUES ('1016', '封', '45', '22');
INSERT INTO `student` VALUES ('1017', '信', '78', '23');
INSERT INTO `student` VALUES ('1018', '故西', '87', '34');
INSERT INTO `student` VALUES ('1019', '依云', '77', '6');
INSERT INTO `student` VALUES ('1020', '零', '99', '99');
INSERT INTO `student` VALUES ('1021', '风致', '45', '65');
INSERT INTO `student` VALUES ('1022', '风离', '78', '34');
INSERT INTO `student` VALUES ('1023', '风', '66', '89');
INSERT INTO `student` VALUES ('1024', '过儿', '54', '78');
INSERT INTO `student` VALUES ('1025', '星', '5', '99');
INSERT INTO `student` VALUES ('1026', '爱', '58', '99');
INSERT INTO `student` VALUES ('1027', '火', '78', '88');
INSERT INTO `student` VALUES ('1028', '逆风', '78', '99');
INSERT INTO `student` VALUES ('1029', '敬', '56', '78');
INSERT INTO `student` VALUES ('1030', '凌风志', '78', '45');

-- ----------------------------
-- Table structure for `stu_user`
-- ----------------------------
DROP TABLE IF EXISTS `stu_user`;
CREATE TABLE `stu_user` (
  `stu_account` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `stu_password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`stu_account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of stu_user
-- ----------------------------
INSERT INTO `stu_user` VALUES ('1234', '1234');
INSERT INTO `stu_user` VALUES ('12345', '12345');
INSERT INTO `stu_user` VALUES ('12345678', '12345678');
INSERT INTO `stu_user` VALUES ('123456789', '123456789');
INSERT INTO `stu_user` VALUES ('87940778', '1535258');
INSERT INTO `stu_user` VALUES ('879407781', '1535258');
